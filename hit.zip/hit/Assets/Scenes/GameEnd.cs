using UnityEngine;
using TMPro; // مهم جداً عشان تستخدم TextMeshPro

public class EndGame : MonoBehaviour
{
    public Transform player;      // اللاعب
    public TMP_Text endText;       // النص اللي يظهر
    public float endX = 8.0f;      // الإحداثيات اللي نتحقق منها
    private bool gameEnded = false; // عشان نوقفه مرة وحدة بس

    private void Start()
    {
        endText.gameObject.SetActive(false); // نخفي النص بالبداية
    }

    private void Update()
    {
        if (!gameEnded && player.position.x >= endX)
        {
            gameEnded = true;                // نخليه ينفذ مرة وحدة بس
            endText.gameObject.SetActive(true); // يظهر النص
            endText.text = "YOU FINISHED THE GAME!!";

            // نوقف حركة اللاعب
            Rigidbody2D rb = player.GetComponent<Rigidbody2D>();
            if (rb != null)
            {
                rb.linearVelocity = Vector2.zero;     // يوقفه تماماً
                rb.bodyType = RigidbodyType2D.Static; // يخليه ثابت ما يتحرك أبداً
            }
        }
    }
}