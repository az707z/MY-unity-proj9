using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro; 

public class MM : MonoBehaviour
{
    public TMP_Text creditsText; 

    private void Start()
    {
        creditsText.gameObject.SetActive(false); 
    }

    public void PlayGame()
    {
        SceneManager.LoadScene("s1"); 
    }

    public void ShowCredits()
    {
        creditsText.gameObject.SetActive(true);
        creditsText.text = "ABDULAZIZ & ABDULMALIK"; 
    }

    public void QuitGame()
    {
        Application.Quit();
        Debug.Log("Game is Quit");
    }
}