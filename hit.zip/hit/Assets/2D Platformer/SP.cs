using UnityEngine;
using UnityEngine.SceneManagement;

public class SP : MonoBehaviour
{
    public Transform player;
    public float endX = 8.468255f; // النقطة اللي إذا وصلها اللاعب، ينتقل المشهد

    private void Update()
    {
        if (player.position.x >= endX)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
    }
}