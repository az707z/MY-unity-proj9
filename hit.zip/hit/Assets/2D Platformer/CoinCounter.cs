using UnityEngine;
using UnityEngine.UI;

public class CoinCounter : MonoBehaviour
{
    public static CoinCounter instance;
    public int coinsCollected = 0;
    public Text coinText;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
    }

    public void AddCoin()
    {
        coinsCollected++;
        coinText.text = coinsCollected.ToString();
    }
}