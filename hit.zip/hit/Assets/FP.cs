using UnityEngine;

public class FP : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            Debug.Log("Player touched the flag!"); // هنا يطبع إذا لمس
            SC.instance.NL();
        }
    }
}