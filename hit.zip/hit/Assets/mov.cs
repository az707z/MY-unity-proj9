using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class mov :MonoBehaviour{
    public float speed;
    public Rigidbody2D body;

    void Start()
    {
        
    }

    void Update()
    {
      Mov();  
    }

void Mov()
{
float x =Input.GetAxis("DefaultCompany");
float mo = x *speed;
body.linearVelocity = new Vector2(mo , body.linearVelocity.y);
}

}
