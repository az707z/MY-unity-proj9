using UnityEngine;
using UnityEngine.SceneManagement;

public class WinManager : MonoBehaviour
{
    public GameObject winPanel;
    public Transform player;
    public float endX; 

    private bool gameEnded = false;

    private void Update()
    {
        if (!gameEnded && player.position.x >= endX)
        {
            gameEnded = true;
            winPanel.SetActive(true);
            Time.timeScale = 0f; 
        }
    }

    public void BackToMainMenu()
    {
        Time.timeScale = 1f; 
        SceneManager.LoadScene("S0"); 
    }
}