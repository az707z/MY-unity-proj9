using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
public class SC : MonoBehaviour
{
    public static SC instance;
    private void Awake()
    {
        if(instance==null)
        {
            
            DontDestroyOnLoad(gameObject);
        }
        else{
            Destroy(gameObject);
        }
    }

    public void NL()
{
SceneManager.LoadSceneAsync(SceneManager.GetActiveScene().buildIndex+1);
}
    public void LS(string S1)
    {
      SceneManager.LoadSceneAsync(S1);
    }

}