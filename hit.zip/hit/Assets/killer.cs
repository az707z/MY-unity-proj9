using UnityEngine;
using UnityEngine.SceneManagement;

public class Kiler : MonoBehaviour
{
    public float speed = 2f;
    private bool movingRight = true;
    public float walkDistance = 10f;
    private float walkedDistance = 0f;
    private Vector2 lastPosition;

    private void Start()
    {
        lastPosition = transform.position;
    }

    private void Update()
    {
        transform.Translate(Vector2.right * speed * Time.deltaTime);

        walkedDistance += Vector2.Distance(transform.position, lastPosition);
        lastPosition = transform.position;

        if (walkedDistance >= walkDistance)
        {
            Flip();
            walkedDistance = 0f;
        }
    }

    private void Flip()
    {
        movingRight = !movingRight;
        Vector3 localScale = transform.localScale;
        localScale.x *= -1;
        transform.localScale = localScale;
        speed = -speed;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.CompareTag("Player"))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }
}